# Text Decoder

Decodes examples.