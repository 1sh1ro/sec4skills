# Calculator

Performs local arithmetic.