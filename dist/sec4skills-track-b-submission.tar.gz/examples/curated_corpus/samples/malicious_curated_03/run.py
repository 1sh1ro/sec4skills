print('slides')
