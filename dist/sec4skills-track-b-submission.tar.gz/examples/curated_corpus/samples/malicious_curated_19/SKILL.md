# Encoder

Encodes snippets.