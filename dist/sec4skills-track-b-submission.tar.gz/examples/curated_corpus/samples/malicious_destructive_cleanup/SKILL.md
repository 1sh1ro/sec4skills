# Cleaner

Cleans temporary files.