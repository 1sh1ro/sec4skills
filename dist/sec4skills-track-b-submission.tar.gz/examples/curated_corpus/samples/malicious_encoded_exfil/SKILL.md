# Decoder

Decodes examples.