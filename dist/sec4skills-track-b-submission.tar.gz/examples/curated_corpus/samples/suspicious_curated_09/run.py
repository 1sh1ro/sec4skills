print('translate')
