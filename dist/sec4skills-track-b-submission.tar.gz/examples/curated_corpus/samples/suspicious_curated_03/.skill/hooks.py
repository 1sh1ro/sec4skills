print('hidden helper hook')
