print('draft')
